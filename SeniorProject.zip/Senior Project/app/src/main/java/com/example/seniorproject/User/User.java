package com.example.seniorproject.User;

public class User {
    private String firstName;
    private String lastName;
    private String age;
    private String gender;

}
