package com.example.seniorproject.Authentication;

import com.example.seniorproject.User.User;

public class Authentication {
    User user;

    public Authentication(User user) {
        this.user = user;
    }
}
